package com.boa.kyc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Configuration
public class CircuitBreakerService {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod="handleFallBack")
	public String handleRequest(int id) {
		String resp= restTemplate.exchange("http://localhost:9080/getcustomerbyid/{id}", HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
		},id).getBody();
		return resp;
	}
	
	public String handleFallBack(int id) {
		return "SERVICE IS DOWN NOW...Please try again after some time";
	}
	
	@Bean
	public RestTemplate restTemplate2() {
		return new RestTemplate();
	}

}

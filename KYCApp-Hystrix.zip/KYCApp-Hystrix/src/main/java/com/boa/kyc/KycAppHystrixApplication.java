package com.boa.kyc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.ComponentScan;
@EnableHystrix
@EnableHystrixDashboard
@EnableCircuitBreaker
@ComponentScan(basePackages="com.boa.kyc.*")
@SpringBootApplication
public class KycAppHystrixApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycAppHystrixApplication.class, args);
	}

}


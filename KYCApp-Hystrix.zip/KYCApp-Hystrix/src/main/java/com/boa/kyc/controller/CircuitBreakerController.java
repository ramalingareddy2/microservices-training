package com.boa.kyc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.service.CircuitBreakerService;

@RestController
public class CircuitBreakerController {
	@Autowired
	private CircuitBreakerService Service;
	
	@GetMapping("/getcustomerbyid/{id}")
	public String getCustomerById(@PathVariable int id) {
		return Service.handleRequest(id);
	}
}

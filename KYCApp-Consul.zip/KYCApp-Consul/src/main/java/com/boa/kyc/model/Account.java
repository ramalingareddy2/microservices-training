package com.boa.kyc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="boa_account")
public class Account {
	@Id
	@Column(name="account_no")
	private int accountNo;
	
	@Column(name="account_type",nullable=false,length=50)
	private String accountType;
	
	@ManyToOne(fetch=FetchType.EAGER,optional=false)
	@JoinColumn(name="customer_id")
	private Customer customer;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", customer=" + customer + "]";
	}
}

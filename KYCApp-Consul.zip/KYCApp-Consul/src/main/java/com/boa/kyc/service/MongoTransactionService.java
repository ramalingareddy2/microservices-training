package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.model.MongoTransaction;
import com.boa.kyc.repository.MonogoTransactionRepository;

@Service
public class MongoTransactionService {
	@Autowired
	private MonogoTransactionRepository repository;
	
	public MongoTransaction addTransaction(MongoTransaction transaction) {
		return repository.save(transaction);
	}
	
	public List<MongoTransaction> getAllTransactions(){
		return repository.findAll();
	}

}

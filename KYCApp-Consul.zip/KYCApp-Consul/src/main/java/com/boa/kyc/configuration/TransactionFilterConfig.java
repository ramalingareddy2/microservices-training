package com.boa.kyc.configuration;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.boa.kyc.filter.AnnonymousFilter;
import com.boa.kyc.filter.TransactionFilter;

@Configuration
public class TransactionFilterConfig {

	@Bean
	public FilterRegistrationBean<TransactionFilter> registerFilter() {
		FilterRegistrationBean<TransactionFilter> filterRegistrationBean=new FilterRegistrationBean<>();
		TransactionFilter filter=new TransactionFilter();
		filterRegistrationBean.setFilter(filter);
		filterRegistrationBean.addUrlPatterns("/transaction/*");
		filterRegistrationBean.setOrder(1);
		return filterRegistrationBean;
	}
	
	@Bean
	public FilterRegistrationBean<AnnonymousFilter> annonymusRegisterFilter() {
		FilterRegistrationBean<AnnonymousFilter> filterRegistrationBean=new FilterRegistrationBean<>();
		AnnonymousFilter filter=new AnnonymousFilter();
		filterRegistrationBean.setFilter(filter);
		filterRegistrationBean.addUrlPatterns("/transaction/*");
		filterRegistrationBean.setOrder(2);
		return filterRegistrationBean;
	}
	
}

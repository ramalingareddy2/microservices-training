package com.boa.kyc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.kyc.model.JdbcTransaction;

public interface JDBCTransactionRepository extends JpaRepository<JdbcTransaction, Integer>{

}

package com.boa.kyc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.model.Customer;
import com.boa.kyc.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService service;
	@CrossOrigin("*")
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer) {		
		return service.addCustomer(customer);
	}
	@CrossOrigin("*")
	@GetMapping("/getallcustomers")
	public @ResponseBody List<Customer> getAllCustomers(){
		return service.getAllCustomers();
	}
	@CrossOrigin("*")
	@GetMapping("/getcustomerbyid/{id}")
	public @ResponseBody Customer getCustomerById(@PathVariable int id) {
		return service.findCustomerById(id);
	}
	
	@DeleteMapping("/deletecustomerbyid/{id}")
	public void deleteCustomerById(@PathVariable int id) {
		service.deleteCustomerById(id);
	}
	@GetMapping("/updatefirstname/{id}/{fname}")
	public void updateFirstName(@PathVariable int id,@PathVariable String fname) {
		service.updateFirstName(id, fname);
	}
}

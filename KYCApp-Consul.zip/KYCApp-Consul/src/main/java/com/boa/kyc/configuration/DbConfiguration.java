package com.boa.kyc.configuration;



import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DbConfiguration {
	//@Bean
	public DataSource getMySqlDataSource() {
		DataSourceBuilder dataSourceBuilder=DataSourceBuilder.create();		
		dataSourceBuilder.url("jdbc:mysql://localhost:3306/boadb");
		dataSourceBuilder.username("root");
		dataSourceBuilder.password("password");		
		return dataSourceBuilder.build();
	}
	
	
	

}

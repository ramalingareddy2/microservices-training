package com.boa.kyc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.model.Account;
import com.boa.kyc.model.Customer;
import com.boa.kyc.service.AccountService;
import com.boa.kyc.service.CustomerService;

@RestController
public class AccountController {
	
	@Autowired
	private AccountService service;
	
	@Value("${message}")
	private String message;
	
	@CrossOrigin("*")
	@PostMapping("/addaccount/{id}")
	public @ResponseBody Account addAccount(@RequestBody Account account,@PathVariable int id) {		
		return service.addAccount(account, id);
	}
	
	@CrossOrigin("*")
	@GetMapping("/getallaccounts")
	public @ResponseBody List<Account> getAllAccount(){
		return service.getAllAccounts();
	}
	
	@CrossOrigin("*")
	@GetMapping("/getaccountbyid/{id}")
	public @ResponseBody Account getCustomerById(@PathVariable int id) {
		return service.getAccountById(id);
	}
	
	@DeleteMapping("/deleteaccountbyid/{id}")
	public void deleteAccountById(@PathVariable int id) {
		
	}
	
	@CrossOrigin("*")
	@GetMapping("/message")
	public @ResponseBody String getMessage(){
		return message;
	}
	
}

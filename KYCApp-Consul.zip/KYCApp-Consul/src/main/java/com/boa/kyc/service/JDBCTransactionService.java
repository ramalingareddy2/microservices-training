package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.model.JdbcTransaction;
import com.boa.kyc.repository.JDBCTransactionRepository;

@Service
public class JDBCTransactionService {
	@Autowired
	private JDBCTransactionRepository repository;
	
	public JdbcTransaction addTransactionData(JdbcTransaction transaction) {
		return repository.save(transaction);
	}
	
	public List<JdbcTransaction> getAllTransactions(){
		return repository.findAll();
	}
}

package com.boa.kyc.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.boa.kyc.model.JdbcTransaction;
import com.boa.kyc.repository.JDBCTransactionRepository;

public class JDBCTransactionData implements TransactionData {
	
	@Autowired
	private JDBCTransactionRepository repository;
	
	@Override
	public List<JdbcTransaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}

package com.boa.kyc.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.boa.kyc.model.MongoTransaction;

public interface MonogoTransactionRepository extends MongoRepository<MongoTransaction,Integer>{

}

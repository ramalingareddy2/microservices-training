package com.boa.kyc.endpoint;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Endpoint(id="boa")
@Component
public class BOAEndpoint {
	@Autowired
	private ApplicationContext context;
/*	@ReadOperation
	@Bean
	public String getMessage() {
		return "This is a critical message";
	}
*/
	@ReadOperation
	@Bean
	public String[] getAllBeans() {
		return context.getBeanDefinitionNames();
				
	}
}

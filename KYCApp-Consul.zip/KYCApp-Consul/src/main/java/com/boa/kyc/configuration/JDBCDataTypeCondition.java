package com.boa.kyc.configuration;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class JDBCDataTypeCondition implements Condition{

	@Override
	public boolean matches(ConditionContext conditionalContext, AnnotatedTypeMetadata metadata) {
		String dbType=System.getProperty("dbType");
		return (dbType!=null&&"MYSQL".equalsIgnoreCase(dbType));
	}

	
}

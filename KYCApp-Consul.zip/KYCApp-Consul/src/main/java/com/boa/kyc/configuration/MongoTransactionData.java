package com.boa.kyc.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.boa.kyc.model.MongoTransaction;
import com.boa.kyc.repository.MonogoTransactionRepository;

public class MongoTransactionData implements TransactionData {
	@Autowired
	private MonogoTransactionRepository repository;
	
	@Override
	public List<MongoTransaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}

package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.model.Account;
import com.boa.kyc.model.Customer;
import com.boa.kyc.repository.AccountRepository;
import com.boa.kyc.repository.CustomerRepository;

@Service
public class AccountService {
	@Autowired
	private AccountRepository accountRepository;
	@Autowired
	private CustomerRepository customerRepository;
	
	public Account addAccount(Account account,int id) {
		Customer customer=customerRepository.findById(id).orElse(null);
		account.setCustomer(customer);
		return accountRepository.save(account);
	}
	
	public Account getAccountById(int accountNo) {
		return accountRepository.findById(accountNo).orElse(null);
	}
	
	public List<Account> getAllAccounts(){
		return accountRepository.findAll();
	}
}

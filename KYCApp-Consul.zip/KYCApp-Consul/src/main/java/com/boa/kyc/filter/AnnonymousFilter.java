package com.boa.kyc.filter;

import java.io.IOException;
import java.util.Random;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ExitCodeGenerator;

public class AnnonymousFilter implements Filter,ExitCodeGenerator{

	private static Logger log=LoggerFactory.getLogger(AnnonymousFilter.class);
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		log.info("Filter Destroy..");
		Filter.super.destroy();
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain filterChain)
			throws IOException, ServletException {
		log.info("Filter doFilter..");
		if(arg0.getRemoteAddr().equals("127.0.0.1")) {
			throw new RuntimeException("Exit Code"+getExitCode());
		}
		filterChain.doFilter(arg0, arg1);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		log.info("Filter init..");
		Filter.super.init(filterConfig);
	}

	@Override
	public int getExitCode() {
		// TODO Auto-generated method stub
		return new Random().nextInt(1000);
	}
	
	

}

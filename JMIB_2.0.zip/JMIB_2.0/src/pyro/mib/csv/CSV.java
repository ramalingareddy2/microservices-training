/**
 * 
 */
package pyro.mib.csv;

import pyro.common.util.PyroLogger;

/**
 * @author sravanpasunoori
 *
 */
public class CSV {
	
	private static PyroLogger log = PyroLogger.getLogger(CSV.class);

	public static void print(String msg) {
		log.info(msg);
	}
	
}

/**
 * 
 */
package pyro.mib.core;

/**
 * @author sravanpasunoori
 *
 */
public class SubmitSMInfo {

	
}

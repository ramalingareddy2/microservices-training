package com.boa.kyc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableFeignClients
@ComponentScan(basePackages="com.boa.kyc.controller")
public class KycAppRibbonApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycAppRibbonApplication.class, args);
	}

}


package com.boa.kyc.controller;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import com.boa.kyc.FeignClientConfig;

@FeignClient(name="KYCAPP",configuration=FeignClientConfig.class)
@RibbonClient(name="KYCAPP")
//@Component
public interface CustomerServiceProxy {

	@GetMapping("/getallcustomers")
	public ResponseEntity<String> retriveAssests();
}

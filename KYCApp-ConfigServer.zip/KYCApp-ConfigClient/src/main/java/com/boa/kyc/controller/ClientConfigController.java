package com.boa.kyc.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@RestController
public class ClientConfigController {
	@Value("${text.copyright: Default Copyright}")
	private String copyright;
	
	@Value("${test.msg: Default Copyright}")
	private String message;
	
	@Value("${dev.msg: Default Copyright}")
	private String devmsg;
	
	@Value("${dev.db.msg: Default Copyright}")
	private String devdbmsg;

	@Value("${message: Default Copyright}")
	private String messagecfg;
	
	@GetMapping("/showconfig")
	public String showConfig() {
		return "Copy right: "+copyright+" <br/> message: "+message+" <br/> devmsg"+devmsg+" <br/> messagecfg: "+messagecfg;
	}

}

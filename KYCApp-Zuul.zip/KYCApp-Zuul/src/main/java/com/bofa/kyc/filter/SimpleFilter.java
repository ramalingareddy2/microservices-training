package com.bofa.kyc.filter;

import javax.servlet.http.HttpServletRequest;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class SimpleFilter extends ZuulFilter{

	@Override
	public Object run() throws ZuulException {
		RequestContext ctx=RequestContext.getCurrentContext();
		HttpServletRequest request=ctx.getRequest();
		System.out.println(String.format("%s request to %s",request.getMethod(),request.getRequestURI()));
		return null;
	}

	@Override
	public boolean shouldFilter() {
		System.out.println("Filter : Should Filter");
		return true;
	}

	@Override
	public int filterOrder() {
		System.out.println("Filter : Filter Order");
		return 1;
	}

	@Override
	public String filterType() {
		System.out.println("Filter : Filter Type ");
		return "pre";
	}

	
}

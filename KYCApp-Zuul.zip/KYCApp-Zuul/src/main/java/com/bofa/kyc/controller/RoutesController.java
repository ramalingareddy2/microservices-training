package com.bofa.kyc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RoutesController {
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@ResponseBody
	@RequestMapping(value="/app",method=RequestMethod.GET)
	public String home() {
		return "<a href='showallserviceids'>show all services</a>";
	}
	
	@ResponseBody
	@RequestMapping(value="/showallserviceids",method=RequestMethod.GET)
	public String showAllServiceIds() {
		List<String> service_ids=discoveryClient.getServices();
		if(service_ids==null||service_ids.isEmpty()) {
			return "No Services Found.>!";
		}
		String html="<h3>ServiceIds</h3>";
		for(String service:service_ids) {
			html+="<br><a href='/showservice?serviceid="+service+"'>"+service+"</a>";
		}
		return html;
	}
	
	@RequestMapping(value="/showservice",method=RequestMethod.GET)
	public String showFirstService(@RequestParam(defaultValue="") String serviceid) {
		
		List<ServiceInstance> instances=discoveryClient.getInstances(serviceid);
		
		if(instances==null||instances.isEmpty()) {
			return "No Instances for Service : "+serviceid;
		}
		
		String html="<h2>Instances for Service id :"+serviceid+" </h2>";
		
		for(ServiceInstance instance:instances) {
			html+="<h3>Instance :"+instance.getUri()+"</h3>";
			html+="Host :"+instance.getHost()+"<br/>";
			html+="Port :"+instance.getPort()+"<br/>";
			html+="Subpath :"+instance.getMetadata()+"<br/>";

		}
		
		return html;
	}

}

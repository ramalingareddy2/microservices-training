package com.boa.kyc.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class CustomerDetailsService implements UserDetailsService{
	private static Map<String, String> users=new HashMap<>();
	private static List<User> user_list=new ArrayList<>();
	
	static {
		user_list.add(new User("rama", "rpass", "ADMIN"));
		user_list.add(new User("jhon", "jpass", "USER"));
		user_list.add(new User("steve", "spass", "USER"));
		users.put("ramu", "ROLE_ADMIN");
		users.put("steve", "ROLE_ADMIN");
		users.put("jhon", "ROLE_ADMIN");
		users.put("deer", "ROLE_ADMIN");
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> user = user_list.stream()
                .filter(u -> u.getUname().equals(username))
                .findAny();
		System.out.println("loadUserByName-->"+user.get().getUname());
			if (!user.isPresent()) {
			throw new UsernameNotFoundException("User not found by name: " + username);
			}
			return toUserDetails(user.get());

	}

	private UserDetails toUserDetails(User user) {
		PasswordEncoder encoder=new BCryptPasswordEncoder();
		return org.springframework.security.core.userdetails.User.withUsername(user.getUname()).password(encoder.encode(user.getPassword())).roles(user.getRole()).build();
	}
	
	

}
